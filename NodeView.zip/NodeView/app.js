//declaration
var express = require('express');
var bodyParser = require('body-parser');
var ejs = require('ejs');

var login = require('./controllers/login');
var home = require('./controllers/home');
var adregister = require('./controllers/adminregister');
var register = require('./controllers/register');
var profile = require('./controllers/profile');
var app = express();

//configuration
app.set('view engine', 'ejs');

//middleware
app.use(bodyParser.urlencoded({extended: false}));
app.use('/login', login);
app.use('/home', home);
app.use('/registeradmin', adregister);
app.use('/register', register);
app.use('/profile', profile);

//routes
app.get('/', function(req, res){
	res.render('index');
});

//server startup
app.listen(3000, function(){
	console.log('server started at 3000!');
});