var db = require('./db');

module.exports = {
    validate: function(user, callback){
        var sql = "SELECT * from users where username=? and password=?";
        db.getResults(sql, [user.username, user.password], function(results){
            if(results.length > 0){
                callback(true);
            }else{
                callback(false);
            }
        })
    },
    insert: function(user, callback){
        var sql = "insert into users values(?,?,?,?,?,?)";
        db.execute(sql, [user.name, user.email, user.mobile, user.username, user.password, user.type], function(status){
            if(status){
                callback(true);
            }else{
                callback(false);
            }
        })
    } ,

    getByUname: function(user, callback){
        var sql = "select * from users where username=?";
        db.getResults(sql, [user], function(results){
            if(results.length > 0){
                callback(results[0]);
            }else{
                callback(null);
            }
        })
    } 
}