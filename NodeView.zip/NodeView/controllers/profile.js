var express = require('express');
var router = express.Router();
var userModel = require.main.require('./models/user-model');


// router.get('*', function(req, res, next)
// {
//     if(req.cookies['username'] == null){
//         res.redirect('/login')
//     }else{
//         next();
//     }
// });


// router.get('/', function(req, res){
//     userModel.getByUname(req.cookies['username'], function(result){
//         res.render('profile/index');
//     })
// });

router.get('/:id', function(req, res){
    // res.send(req.params.id);
    userModel.getByUname(req.params.id, function(result){
         res.render('profile/index', {profile: result});
        res.send(result);
    })
})

module.exports = router;