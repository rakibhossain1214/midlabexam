var express = require('express');
var router = express.Router();
var userModel = require.main.require('./models/user-model');

router.get('/', function(req, res){
	console.log('User register page requested!');
	res.render('register/index');
});

router.post('/', function(req, res){
	var user = {
        name: req.body.name,
        email: req.body.email,
        mobile: req.body.mobile,
        username: req.body.uname,
        password: req.body.password,
        type: 'member'
    };

    userModel.insert(user, function(status){
        if(status){
            res.redirect('/login');
            console.log('regsitration success!');
        }else{
            console.log('registration failed!');
        }
    });
});

module.exports = router;